package com.example.animals
open class Animals {
var Sex : String = ""
}
