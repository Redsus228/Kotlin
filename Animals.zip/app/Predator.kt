package com.example.animals
class Predator(
    Name: String,
    Sex: String,
    val Diet: String = Meat food
    var mlistP = mutableListOf(Bear,Tiger,Wolf)
): Animals(Sex) {

}
fun Addtolist(){
    mlistH.add('Monkey','Lion')
    println(mlistP)