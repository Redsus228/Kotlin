package com.example.animals
class Herbivore(
    Sex: String,
    val Diet: String = Plant food
    var mlistH = mutableListOf('Sheep','Cowl','Horse')
): Animals(Sex) {

}
fun Addtolist(){
    mlistH.add('rabbit','panda')
    println(mlistH)
}