public class Animal {
}
